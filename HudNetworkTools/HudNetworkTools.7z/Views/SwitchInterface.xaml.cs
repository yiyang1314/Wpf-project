﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static HudNetworkTools.Commons.ApplicationGlobalEvent;

namespace HudNetworkTools.Views
{
    /// <summary>
    /// SwitchInterface.xaml 的交互逻辑
    /// </summary>
    public partial class SwitchInterface : UserControl
    {
        public SwitchInterface()
        {
            InitializeComponent();
        }



        DataManage dataManage = new DataManage();         //用于切换的用户控件--数据管理控件
        private double originalHeight = 0.0;
        private void SwInterface_Load(object sender, RoutedEventArgs e)
        {
            originalHeight = stackPanelData.ActualHeight;
            dataManage.CtrlSwitchEvent += new CtrlSwitchHandler(CtrlSwitch_CatData);
            LoadStackPanelRight(dataManage);
        }

        //实现界面切换到查看数据界面
        private void CtrlSwitch_CatData()
        {
           //CatDataControl catData = new CatDataControl(dataManage.Result_NumStr);                          //用于切换的用户控件--查看数据控件
           //catData.CtrlSwitchEvent += new CtrlSwitchHandler(CtrlSwitch_dataManage);
           //LoadStackPanelRight(catData);
        }

        //实现界面切换到数据管理界面
        private void CtrlSwitch_dataManage()
        {
            LoadStackPanelRight(dataManage);
        }

        //加载用户控件功能函数
        private void LoadStackPanelRight(UserControl userControl)
        {
            stackPanelData.Children.Clear();
            stackPanelData.Children.Add(userControl);
        }

    }
}
