﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static HudNetworkTools.Commons.ApplicationGlobalEvent;

namespace HudNetworkTools.Views
{
    /// <summary>
    /// DataManage.xaml 的交互逻辑
    /// </summary>
    public partial class DataManage : UserControl
    {
        public DataManage()
        {
            InitializeComponent();
        }

        public event CtrlSwitchHandler CtrlSwitchEvent;               //定义事件,用于界面切换 
        
        /// <summary>
        /// 查看数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CatData_Click(object sender, RoutedEventArgs e)
        {
            if (this.dgData.SelectedItem == null)
            {
               //MyDialog md = new MyDialog(1, "未选择需要查看的对象，请选择！");
               //md.Show();
            }
            else
            {
                //Result_NumStr = ((DataRowView)this.dgData.SelectedItem).Row["id"].ToString();
                //if (Result_NumStr != "")
                //{
                //    //触发事件改变父窗口的值
                //    if (CtrlSwitchEvent != null)
                //    {
                //        CtrlSwitchEvent();
                //    }
                //}
                //else
                //{
                //    MyDialog md = new MyDialog(1, "不允许查看空值！");
                //    md.Show();
                //}
            }
        }

        private void DatePicker_CalendarClosed(object sender, RoutedEventArgs e)
        {

        }

        private void Check_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void Combox_DropDownClosed(object sender, EventArgs e)
        {

        }

        private void dgData_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ConditionQuery_Click(object sender, RoutedEventArgs e)
        {

        }

        private void DelData_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
