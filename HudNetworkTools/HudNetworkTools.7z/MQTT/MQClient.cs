﻿using MQTTnet.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HudNetworkTools.MQTT
{
    public class MQClient
    {
        IMqttClient mqttClient;  //MQTT客户端实例

        string clientID; //机器ID


        string message;

        public string Message  //用于接收当前 消息
        {
            get { return message; }
            set { message = value; }
        }

        public MQClient()
        {

        }
        //开启MQTT连接
        public async void SignMqttServer()
        {
            var options = new MqttClientOptionsBuilder()
             .WithClientId(clientID) //传递ClientID 
             .WithTcpServer("127.0.0.1", 1883)  //MQTT服务的地址
             .WithCredentials("admin", "123456") //传递账号密码
             .WithCleanSession()
             .Build();
            //mqttClient = new MqttFactory().CreateMqttClient();// .CreateManagedMqttClient();
            //mqttClient.Connected += MqttClient_Connected;
            //mqttClient.Disconnected += MqttClient_Disconnected;
            //mqttClient.ApplicationMessageReceived += MqttClient_ApplicationMessageReceived; //创建消息接受事件

            await mqttClient.ConnectAsync(options);
            //await mqttClient.SubscribeAsync(clientID);
        }

        private void MqttClient_ApplicationMessageReceived(object sender, MqttApplicationMessageReceivedEventArgs e)
        {
            Message += "收到的信息:" + Encoding.UTF8.GetString(e.ApplicationMessage.Payload) + "\r\n";
        }

        private void MqttClient_Disconnected(object sender, MqttClientDisconnectedEventArgs e)
        {
            Message += "客户端断开";
        }

        private void MqttClient_Connected(object sender, MqttClientConnectedEventArgs e)
        {
            Message += "客户端已连接" + "\r\n";
            //mqttClient.SubscribeAsync(new TopicFilterBuilder().WithTopic(clientID).Build()); //关联服务端订阅, 用于接受服务端推送信息

        }
    }
}
