﻿
using MQTTnet.Client;
using MQTTnet.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HudNetworkTools.MQTT
{
    public class MQServer
    { 
        MqttServer mqttServer;  //MQTT服务端实例

        string message;

        /// <summary>
        /// 消息   用于界面显示
        /// </summary>
        public string Message
        {
            get { return message; }
            set { message = value; }
        }



    //开启MQTT服务
    public void OpenMqttServer()
    {
        
        var options = new MqttServerOptions();
/*
        //拦截登录
        options.ConnectionValidator = c =>
        {
            try
            {
                Message += string.Format("用户尝试登录:用户ID：{0}\t用户信息：{1}\t用户密码：{2}", c.ClientId, c.Username, c.Password) + "\r\n";
                if (string.IsNullOrWhiteSpace(c.Username))
                {
                    Message += string.Format("用户：{0}登录失败，用户信息为空", c.ClientId) + "\r\n";

                    c.ReturnCode = MQTTnet.Protocol.MqttConnectReturnCode.ConnectionRefusedBadUsernameOrPassword;
                    return;
                }
                //解析用户名和密码，这个地方需要改成查找我们自己创建的用户名和密码。
                if (c.Username == "admin" && c.Password == "123456")
                {
                    c.ReturnCode = MqttConnectReturnCode.ConnectionAccepted;
                    Message += c.ClientId + " 登录成功" + "\r\n";
                    ClientInsTances.Add(new ClientInstance()
                    {
                        ClientID = c.ClientId,
                        UserName = c.Username,
                        PassWord = c.Password
                    });
                    return;
                }
                else
                {
                    c.ReturnCode = MqttConnectReturnCode.ConnectionRefusedBadUsernameOrPassword;
                    Message += "用户名密码错误登陆失败" + "\r\n";
                    return;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("登录失败:" + ex.Message);
                c.ReturnCode = MqttConnectReturnCode.ConnectionRefusedIdentifierRejected;
                return;
            }
        };
        //拦截订阅
        options.SubscriptionInterceptor = async context =>
        {
            try
            {
                Message += "用户" + context.ClientId + "订阅" + "\r\n";
            }
            catch (Exception ex)
            {
                Console.WriteLine("订阅失败:" + ex.Message);
                context.AcceptSubscription = false;
            }
        };
        //拦截消息
        options.ApplicationMessageInterceptor = context =>
        {
            try
            {
                //一般不需要处理消息拦截
                // Console.WriteLine(Encoding.UTF8.GetString(context.ApplicationMessage.Payload));
            }
            catch (Exception ex)
            {
                Console.WriteLine("消息拦截:" + ex.Message);
            }
        };

        mqttServer.ClientDisconnected += ClientDisconnected;
        mqttServer.ClientConnected += MqttServer_ClientConnected;
        mqttServer.Started += MqttServer_Started;
        mqttServer.StartAsync(options);
        mqttServer = new MQTTnet.MqttFactory().CreateMqttServer();*/
        }


    private void MqttServer_Started(object sender, EventArgs e)
    {
        Message += "消息服务启动成功：任意键退出" + "\r\n";
    }

    private void MqttServer_ClientConnected(object sender, MqttClientConnectedEventArgs e)
    {
        //客户端链接
        //Message += e.ClientId + "连接" + "\r\n";
    }

    private void ClientDisconnected(object sender, MqttClientDisconnectedEventArgs e)
    {
        //客户端断开
        //Message += e.ClientId + "断开" + "\r\n";
    }

    /// <summary>
    /// 客户端推送信息    -  用于测试服务推送
    /// </summary>
    /// <param name="clientID"></param>
    /// <param name="message"></param>
    public void SendMessage(string clientID, string message)
    {
        //mqttServer.PublishAsync(new MqttApplicationMessage
        //{
        //    Topic = clientID,
        //    //QualityOfServiceLevel = MqttQualityOfServiceLevel.ExactlyOnce,
        //    Retain = false,
        //    Payload = Encoding.UTF8.GetBytes(message),
        //});
    }
    }
}
