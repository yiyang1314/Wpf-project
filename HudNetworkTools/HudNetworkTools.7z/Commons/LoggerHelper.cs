﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HudNetworkTools.Commons
{
    public static class LoggerHelper
    {
        public static ILog Log(string LoggerName)
        {
            //log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            return LogManager.GetLogger(LoggerName);
        }

        public static void WriteLog(string msg = "dffd", string loggerName = "InfoLogger")
        {
            LogManager.GetLogger(loggerName).Info(msg);
        }

    }

}
