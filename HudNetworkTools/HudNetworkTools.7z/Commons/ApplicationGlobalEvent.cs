﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HudNetworkTools.Commons
{
    public class ApplicationGlobalEvent
    {
        public delegate void CtrlSwitchHandler();   //定义委托
    }
}
