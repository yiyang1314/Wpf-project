﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfDemo_Projects.pages;
using WpfDemo_Projects.views;

namespace WpfDemo_Projects
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Collpes_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void ToggleMinClick(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void ToggleMax_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState != WindowState.Maximized)
            {
                this.WindowState = WindowState.Maximized;
                mainName.Margin = new Thickness(5);
            }
            else
            {
                this.WindowState = WindowState.Normal;
                mainName.Margin = new Thickness(0);
            }
        }

        private void WinClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void First_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender as Button;
            if (btn.Content.ToString().Equals("Frame1"))
            {
                this.xfeame.Source = new Uri("/WpfDemo_Projects;component/pages/Page1.xaml");
            }
            else 
            {
                this.xfeame.Source = new Uri("/WpfDemo_Projects;component/pages/Page2.xaml");
            }
            
        }

        private void First2_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender as Button;
            NavWindow1 navw = new NavWindow1();
            if (btn.Content.ToString().Equals("content1"))
            {
                navw.Content = new Page2();
            }
            else
            {
                navw.Content  = new Page1();
                
            }
            this.container.Content = navw;
            //Application.Current.MainWindow.Content = new Page2();
        }
    }
}
